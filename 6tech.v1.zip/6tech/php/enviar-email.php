<?php
// Variáveis
$nome = $_POST['nome'];
$email = trim($_POST['email']);
$mensagem = $_POST['mensagem'];
$data_envio = date('d/m/Y');
$hora_envio = date('H:i:s');

// Compor o conteúdo do E-mail
$arquivoHTML = "
        <html>
        <p><b>Nome: </b>" . $nome . "</p>
        <p><b>E-mail: </b>" . $email . "</p>
        <p><b>Mensagem: </b>" . $mensagem . "</p>
        <p>Este e-mail foi enviado em <b>" . $data_envio . "</b> às <b>" . $hora_envio . "</b></p>
        </html>
    ";

// Destinatário do formulário
$destino = "mxspaula@gmail.com";
$assunto = "Contato pelo Site";

// Cabeçalhos do E-mail

$headers['From'] = "$email";
$headers['MIME-Version'] = 'MIME-Version: 1.0';
$headers['Content-type'] = 'text/html; charset=iso-8859-1';

//$headers  = "MIME-Version: 1.0\r\n"; // Alterado para 1.0
//$headers .= "Content-Type: text/html; charset=UTF-8\r\n"; // Definido para UTF-8
//$headers .= "From: " . $email . "\r\n"; // Email do remetente
//$headers .= "Return-Path: " . $destino . "\r\n"; // Definido para o endereço de destino

// Enviar o e-mail
$status = mail($destino, $assunto, $arquivoHTML, $headers);

if($status){
    // Redireciona após envio bem-sucedido
    echo "<meta http-equiv='refresh' content='10;URL=../contato.php'>";
    //echo "<script>location.href='contato.php';</script>";
} else {
    echo "Não foi possível enviar o e-mail.";
}
?>